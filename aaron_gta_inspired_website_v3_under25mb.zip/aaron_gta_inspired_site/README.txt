AARON — THE CITY IS YOURS

GITHUB PAGES DEPLOYMENT PACKAGE
Upload the CONTENTS of this folder to the repository root. Keep index.html beside assets/.

MEDIA
- Includes all nine supplied original JPG photos, plus optimized gallery copies.
- Includes the mobile-optimized 720p MP4 used by the website.
- The large original MP4 is intentionally not included in this deployment package because GitHub browser uploads have a 25 MiB per-file limit. Your original video remains in your original V2 archive and is not modified.
- No photo or video retouching is performed by this website.

This is an unofficial GTA-inspired fan-made personal project, not affiliated with Rockstar Games.
